## Summary

What this pull request changes and why.

## Related issue

Closes #

## Type of change

- [ ] Content / field site
- [ ] Transcription / translation
- [ ] Bug fix
- [ ] Figure / visualization
- [ ] Accessibility
- [ ] Documentation

## Checks

- [ ] The site opens locally and figures render
- [ ] Images use static `src` / `url()` paths under `assets/`
- [ ] New images have their rights recorded in `ATTRIBUTIONS.md`
- [ ] Any oral-history material has consent (see `docs/consent-template.md`)
- [ ] Coded indices are labelled as such; no fabricated figures
- [ ] Layout works on desktop and mobile
- [ ] No new console errors

## Notes

Anything the reviewers should know.
