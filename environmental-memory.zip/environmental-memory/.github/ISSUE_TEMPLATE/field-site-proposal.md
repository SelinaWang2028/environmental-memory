---
name: Field site proposal
about: Propose a new community or field site to add to the archive
title: "[Field site] "
labels: field-site
assignees: ''
---

**Place and community**
- Location (region, coordinates):
- Community and the people who would be involved:
- The environmental change to be documented:

**Why this site**
What makes this place important, and what stories it can add.

**Consent and ethics**
- How narrators will be informed and consent obtained:
- Preferred attribution / anonymisation approach:
- Any sensitive material (health, legal, minors, third parties):

**Sources and materials**
- Interviews / households planned:
- Photographs, documents, or records available, and their rights:
- Are the images openly licensed or your own?

**Open data**
- Metadata that can be added to `data/`:

**Checklist**
- [ ] Consent plan in place
- [ ] Image rights understood (see `ATTRIBUTIONS.md`)
- [ ] Figures labelled honestly (coded vs official)
