---
name: Bug report
about: Report a problem with the site or its figures
title: "[Bug] "
labels: bug
assignees: ''
---

**Describe the problem**
A clear description of what is wrong.

**To reproduce**
1. Go to '...'
2. Click on '...'
3. Scroll to '...'
4. See the problem

**Expected behavior**
What you expected to happen.

**Environment**
- Device: [desktop / mobile]
- Browser and version:
- Screen width:

**Screenshots**
If helpful, add a screenshot.

**Additional context**
Anything else.
