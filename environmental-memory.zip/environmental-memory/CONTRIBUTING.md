# Contributing to Environmental Memory

Thank you for your interest. This is a public archive, and contributions are
welcome whether you are a researcher, a student, a community member, or a
developer. Please read the [ethics notes](docs/ethics.md) before collecting any
oral history.

## Ways to contribute

- **Field site** — add a new community or deepen an existing one.
- **Transcription / translation** — turn a recording into a transcript and a
  translation.
- **Narrator** — share your own memory.
- **Code & design** — fix a bug, improve accessibility, or add a chart.
- **Photographs & media** — contribute openly licensed images.
- **Review** — check citations, figures, and metadata.

## Before you collect oral history

1. Use the [consent form](docs/consent-template.md) and explain how the material
   will be used and licensed.
2. Let the narrator choose attribution and whether to open the material.
3. Record the consent choice in the narrator's metadata.
4. Do not publish anyone who has not consented; respect withdrawal requests.

## Adding a field site

1. Open a [field-site proposal](.github/ISSUE_TEMPLATE/field-site-proposal.md)
   describing the place, the community, and the consent plan.
2. Add the site to `index.html` following the existing sections (intro,
   fact strip, timeline, voices, figures) and to the Field Sites overview and map.
3. Add the narrator metadata to `data/`.
4. Place images in `assets/` and record their rights in `ATTRIBUTIONS.md`.
5. Keep figures honest: use zero baselines for bars, do not mix unrelated axes,
   and label coded indices as such.

## Code conventions

- **One self-contained file.** Plain HTML, CSS, and vanilla JavaScript; no build
  step, no framework, no external `.js` files.
- Add the new chart's `init` in the existing chart block and register the chart
  for resize.
- Keep all image paths as static `src` or CSS `url()` references to `assets/` —
  never constructed in JavaScript.
- Design responsively and keep keyboard navigation and contrast working.

## Pull-request process

1. Fork the repository and create a topic branch.
2. Make focused commits; keep pull requests reasonably small.
3. Describe what changed and link the related issue.
4. Confirm the site opens locally and figures render on both desktop and mobile.
5. A maintainer will review it; be ready to adjust for ethics or consent.

By contributing, you agree that your code is licensed under the MIT License and
any documentation under CC BY 4.0, and that you have the rights to the material
you submit.
