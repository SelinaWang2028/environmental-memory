# Content License · 内容许可

The **code** in this repository is licensed under the MIT License — see [`LICENSE`](LICENSE).

The **oral-history content** — interview transcripts, quotations, field notes,
translations, and the metadata describing them — is licensed under the

# Creative Commons Attribution 4.0 International License (CC BY 4.0)

You are free to:

- **Share** — copy and redistribute the material in any medium or format
- **Adapt** — remix, transform, and build upon the material for any purpose,
  including commercially

Under the following terms:

- **Attribution** — You must give appropriate credit, provide a link to the
  license, and indicate if changes were made. You may do so in any reasonable
  manner, but not in any way that suggests the licensor endorses you or your use.

Full legal code: <https://creativecommons.org/licenses/by/4.0/legalcode>
Human-readable deed: <https://creativecommons.org/licenses/by/4.0/>

Suggested citation:

> Environmental Memory Project (2026). *Environmental Memory · 环境记忆 —
> A Public Oral History Archive.* Licensed under CC BY 4.0.

## Important boundaries

1. **Narrators retain their rights.** No interview, quotation, or likeness is
   placed under CC BY unless the narrator has granted it through the project's
   informed-consent form (see [`docs/consent-template.md`](docs/consent-template.md)).
   Material pending consent is **not** open.
2. **Third-party and sourced material is excluded** from this grant unless its
   own licence permits reuse. Per-image and per-source status is listed in
   [`ATTRIBUTIONS.md`](ATTRIBUTIONS.md).
3. **Right of withdrawal.** Any narrator may ask to remove or de-identify their
   material; it will be withdrawn from subsequent releases. See
   [`docs/ethics.md`](docs/ethics.md).
