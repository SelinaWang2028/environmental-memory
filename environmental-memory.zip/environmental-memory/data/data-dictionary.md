# Data Dictionary

Machine-readable metadata for the archive. The non-identifying metadata is
released under **CC0 1.0**; the interviews themselves are opened only under
CC BY 4.0 after the narrator signs the consent form. These files describe the
collection; they do not contain interview transcripts.

## Files

| File | Contents |
|---|---|
| `field-sites.json` / `.csv` | The field sites, with coordinates and status |
| `narrators.json` / `.csv` | The Jincheng narrators, roles and research focus |

## `field-sites` fields

| Field | Meaning |
|---|---|
| `id` | Stable identifier used by the site and anchors |
| `name` / `name_zh` | English and Chinese names |
| `country`, `admin` | Country and administrative region |
| `lon`, `lat` | Longitude and latitude (WGS84) |
| `status` | `published` or `in-development` |
| `period` | The period documented |
| `focus` | One-line description of the site's focus |

## `narrators` fields

| Field | Meaning |
|---|---|
| `id` | Narrator code (e.g. `G01`, `C03`) |
| `field_site` | Site the narrator belongs to |
| `group_code` | One-letter group code |
| `group_label` | Group name (see below) |
| `display_name` | Pseudonym / role and age |
| `role_and_background` | Work history and years |
| `research_focus` | Themes covered in the interview |
| `identification` | `pseudonym` (no real names) |
| `narrator_licence` | `pending-consent` until the form is signed, then CC BY 4.0 |
| `data_licence` | Licence of this metadata row |

## Group codes

| Code | Label |
|---|---|
| `G` | Worker (industrial) |
| `C` | Villager |
| `M` | Management |
| `V` | Village committee |
| `Y` | Medical |

## Caveats

- Names shown are pseudonyms; ages are given at the time of interview.
- Charted indices on the site are researcher-coded summaries, not official
  statistics; this is stated on the figures.
- Records with `narrator_licence: pending-consent` are not open as content.
